import logging
from flask import Flask, request, render_template, g, redirect, session, url_for, flash, get_flashed_messages
import sqlite3
import os
import hashlib
import re

LOG_MODE = 'NONE'

logger = logging.getLogger(__name__)
if LOG_MODE == 'NONE':
    logging.disable(logging.CRITICAL)
elif LOG_MODE in ('DEBUG', 'INFO', 'ERROR'):
    level = getattr(logging, LOG_MODE)
    logging.basicConfig(level=level, format='[%(levelname)s] %(asctime)s %(message)s',)
else:
    raise ValueError(f"Error - invalid LOG_MODE: {LOG_MODE}")

app = Flask(__name__)
app.secret_key = os.urandom(24)
db_path = os.getenv('DATABASE', '/data/users.db')

def init_db():
    if os.path.exists(db_path):
        os.remove(db_path)

    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    with sqlite3.connect(db_path) as conn, open('schema.sql', 'r') as db_file:
        conn.executescript(db_file.read())

init_db()

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(db_path)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

@app.route('/', methods=['GET', 'POST'])
def login():

    if session.get('user'):
        return redirect(url_for('forum'))

    msg = ''
    
    if request.method == 'POST':
        user_input = request.form.get('username', '')
        pwd  = request.form.get('password', '')

        if(user_input == '' or pwd == ''):
            msg = 'Popunite sva polja!'
            return render_template('login.html', message=msg)

        if re.search(r"(?i)\b(UNION|SELECT|DELETE|INSERT|UPDATE|DROP)\b|;", user_input):
            msg = 'Neispravan unos korisničkog imena.'
            return render_template('login.html', message=msg)

        pw_hash = hashlib.sha256(pwd.encode()).hexdigest()

        query = f"SELECT username FROM users WHERE username = '{user_input}' AND password_hash = '{pw_hash}';"

        try:
            cursor = get_db().cursor()
            cursor.execute(query)
            row = cursor.fetchone()
            if row:
                session['user'] = row[0] #row[0] = username from DB
                return redirect(url_for('forum'))
            else:
                msg = 'Pogrešno korisničko ime ili lozinka.'

        except Exception as e:
            logger.error(f"Login page error: {e}")
            msg = 'Došlo je do greške. Molimo pokušajte ponovno.'

    return render_template('login.html', message=msg)

@app.route('/register', methods=['GET', 'POST'])
def register():

    if request.method == 'POST':
        user = request.form.get('username', '')
        pwd  = request.form.get('password', '')
        about = request.form.get('about', '')

        if(user == '' or pwd == '' or about == ''):
            msg = 'Popunite sva polja!'
            return render_template('register.html', message=msg)

        if len(user) > 32:
            msg = 'Maksimalna duljina korisničkog imena je 32 znaka!'
            return render_template('register.html', message=msg)

        if not re.fullmatch(r'[A-Za-z0-9_]+', user):
            msg = 'Korisničko ime može sadržavati samo velika i mala slova, brojke i donju crtu (_)!'
            return render_template('register.html', message=msg)

        try:
            hash_pwd = hashlib.sha256(pwd.encode()).hexdigest()
            cursor = get_db().cursor()

            cursor.execute("INSERT INTO users(username, password_hash, about_me, flag) VALUES (?, ?, ?, '');", (user, hash_pwd, about))
            get_db().commit()

            flash('Registracija je uspješna! Možete se prijaviti!')      
            return redirect(url_for('login'))                          

        except Exception as e:
            logger.error(f"Registration page error: {e}")
            msg = 'Neuspješna registracija. Korisničko ime možda već postoji.'
            return render_template('register.html', message=msg)

    return render_template('register.html')

@app.route('/forum', methods=['GET', 'POST'])
def forum():

    if 'user' not in session:
        return redirect(url_for('login'))
    
    user = session['user']
    msg = ''
    cursor = get_db().cursor()

    if request.method == 'POST':
        content = request.form.get('content', '')
        try:
            cursor.execute("SELECT id FROM users WHERE username = ?", (user,))
            row = cursor.fetchone()
            if not row:
                msg = 'Korisnik nije pronađen.'
            else:
                user_id = row[0]
                cursor.execute("INSERT INTO posts(user_id, content) VALUES (?, ?);", (user_id, content))
                get_db().commit()

        except Exception as e:
            logger.error(f"Post forum error: {e}")
            msg = 'Dogodila se greška. Molimo pokušajte ponovo.'

    cursor.execute("SELECT users.username, posts.content, posts.created_at FROM posts JOIN users ON posts.user_id = users.id ORDER BY posts.id ASC;")
    posts = cursor.fetchall()
    return render_template('forum.html', user=user, posts=posts, message=msg)

@app.route('/profile')
def profile():

    if 'user' not in session:
        return redirect(url_for('login'))
    
    user = session['user']
    cursor = get_db().cursor()
    cursor.execute( "SELECT about_me, flag FROM users WHERE username = ?;", (user,))
    row = cursor.fetchone()
    about = row[0] if row else ''
    flag = row[1] if row and user == 'luka654' else None
    return render_template('profile.html', user=user, about=about, flag=flag)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.logger.handlers = logger.handlers
    app.run(host='0.0.0.0', port=5000)