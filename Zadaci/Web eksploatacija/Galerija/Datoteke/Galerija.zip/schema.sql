DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  pwd_hash TEXT NOT NULL
);

INSERT INTO users(username,pwd_hash) VALUES
  ('test_korisnik','3ac73bdf78813e3bd2b871f906638abd64553ce301bd0d3b80ed2fee37b284f1'),
  ('admin','9885d1cb5e0df3d9fde7ffd1076688346ce49160ada14a63bc81c9d29ba8f985');
 
