import logging
import os
import sqlite3
import hashlib
import re
import shutil
import time
from datetime import datetime

from flask import ( Flask, request, render_template, g, redirect, session,url_for, flash, send_from_directory)
from werkzeug.utils import secure_filename

LOG_MODE = 'NONE'
logger = logging.getLogger(__name__)
if LOG_MODE == 'NONE':
    logging.disable(logging.CRITICAL)
elif LOG_MODE in ('DEBUG', 'INFO', 'ERROR'):
    level = getattr(logging, LOG_MODE)
    logging.basicConfig(level=level, format='[%(levelname)s - %(asctime)s] %(message)s')
else:
    raise ValueError(f"Error - invalid LOG_MODE: {LOG_MODE}")

app = Flask(__name__)
app.secret_key = os.urandom(24)

DB_PATH = os.getenv('DATABASE', '/data/users.db')
DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data'))
UPLOAD_FOLDER = os.path.join(DATA_DIR, 'uploads')
INIT_FOLDER = os.path.join(DATA_DIR, 'init_uploads')
ALLOWED_EXT = {'png', 'jpg'}

def init_db():
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

    if os.path.exists(UPLOAD_FOLDER):
        shutil.rmtree(UPLOAD_FOLDER)
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

    schema_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'schema.sql'))
    with sqlite3.connect(DB_PATH) as conn, open(schema_path, 'r') as schema:
        conn.executescript(schema.read())

    if os.path.isdir(INIT_FOLDER):
        for fname in os.listdir(INIT_FOLDER):
            if fname.split('.')[-1].lower() in ALLOWED_EXT:
                source = os.path.join(INIT_FOLDER, fname)
                destination = os.path.join(UPLOAD_FOLDER, fname)
                shutil.copy(source, destination)

init_db()

def get_db():
    db = getattr(g, '_db', None)
    if db is None:
        db = g._db = sqlite3.connect(DB_PATH)
    return db

@app.teardown_appcontext
def close_connection(exc):
    db = getattr(g, '_db', None)
    if db is not None:
        db.close()

def check_file_extension(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT

@app.route('/')
def index():
    if 'user' in session:
        return redirect(url_for('gallery', uid=session['uid']))
    else:
        return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    
    if session.get('user'):
        return redirect(url_for('gallery', uid=session['uid']))

    msg = ''
    if request.method == 'POST':
        user_input = request.form.get('username', '').strip()
        pwd = request.form.get('password', '')

        if not user_input or not pwd:
            msg = 'Popunite sva polja!'
            return render_template('login.html', message=msg)

        if re.search(r"(?i)\b(UNION|SELECT|DELETE|INSERT|UPDATE|DROP|OR)\b|--|'|;", user_input):
            msg = 'Neispravan unos korisničkog imena.'
            return render_template('login.html', message=msg)

        pw_hash = hashlib.sha256(pwd.encode()).hexdigest()
        try:
            cur = get_db().cursor()
            cur.execute("SELECT id, username FROM users WHERE username = ? AND pwd_hash = ?;", (user_input, pw_hash))
            row = cur.fetchone()
            if row:
                session['user'] = row[1]
                session['uid'] = row[0]
                return redirect(url_for('gallery', uid=row[0]))
            else:
                msg = 'Neispravno korisničko ime ili lozinka.'
                
        except Exception as e:
            logger.error(f"Login error: {e}")
            msg = 'Došlo je do greške. Molimo pokušajte ponovno.'

    return render_template('login.html', message=msg)

@app.route('/register', methods=['GET', 'POST'])
def register():
    msg = ''
    if request.method == 'POST':
        user = request.form.get('username', '').strip()
        pwd = request.form.get('password', '')

        if not user or not pwd:
            msg = 'Popunite sva polja!'
            return render_template('register.html', message=msg)

        if len(user) > 32 or not re.fullmatch(r'[A-Za-z0-9_]+', user):
            msg = 'Korisničko ime može biti max 32 znaka (slova, brojke i _).'
            return render_template('register.html', message=msg)

        try:
            pw_hash = hashlib.sha256(pwd.encode()).hexdigest()
            db = get_db()
            db.execute("INSERT INTO users(username, pwd_hash) VALUES (?, ?);", (user, pw_hash))
            db.commit()
            flash('Registracija uspješna! Možete se prijaviti.')
            return redirect(url_for('login'))
        
        except sqlite3.IntegrityError:
            msg = 'Korisničko ime možda već postoji.'

        except Exception as e:
            logger.error(f"Registration error: {e}")
            msg = 'Neuspješna registracija. Molimo pokušajte ponovo.'

    return render_template('register.html', message=msg)

@app.route('/galerija/<int:uid>', methods=['GET', 'POST'])
def gallery(uid):
    
    if 'user' not in session:
        return redirect(url_for('login'))

    db = get_db()
    cur = db.cursor()
    cur.execute("SELECT username FROM users WHERE id = ?;", (uid,))
    row = cur.fetchone()
    if not row:
        return render_template(
            'gallery.html',
            error_msg='Greška - nepostojeći korisnik',
            owner_id=uid,
            owner_name='',
            files=[],
            message=''
        )

    owner_name = row[0]
    msg = ''

    if request.method == 'POST':
        file = request.files.get('file')

        if not file or file.filename == '':
            msg = 'Odaberite sliku!'

        elif file and check_file_extension(file.filename):
            original_filename = secure_filename(file.filename)
            filename, ext = os.path.splitext(original_filename)
            timestamp = int(time.time())
            new_name = f"{uid}_{filename}_{timestamp}{ext}"
            destination = os.path.join(UPLOAD_FOLDER, new_name)

            try:
                file.save(destination)

            except Exception as e:
                logger.error(f"Upload error: {e}")
                msg = 'Dogodila se greška prilikom prijenosa slika. Molimo pokušajte ponovo'
        else:
            msg = 'Nedopušten ili neispravan format datoteke.'

    all_filenames = os.listdir(UPLOAD_FOLDER)
    user_prefix = f"{uid}_"
    user_files = []

    for fname in all_filenames:
        if not fname.startswith(user_prefix):
            continue

        stored_name = fname
        rest = fname[len(user_prefix):]
        base, ext = os.path.splitext(rest)
        parts = base.rsplit('_', 1)
        if len(parts) == 2 and parts[1].isdigit():
            original_filename = parts[0] + ext
            ts = int(parts[1])
            uploaded_at = datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
        else:
            original_filename = rest
            ts = 0
            uploaded_at = 'Nepoznato'

        user_files.append({
            'stored_name': stored_name,
            'display_name': original_filename,
            'uploaded_at': uploaded_at,
            'ts': ts
        })

    user_files.sort(key=lambda x: x['ts'], reverse=True)

    return render_template(
        'gallery.html',
        owner_id=uid,
        owner_name=owner_name,
        files=user_files,
        message=msg,
        error_msg=''
    )

@app.route('/uploads/<path:filename>')
def uploads(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.logger.handlers = logger.handlers
    app.run(host='0.0.0.0', port=5000)
