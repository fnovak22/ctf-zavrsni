import sys

def r(b):
    right = b >> 3
    left  = (b & ((1 << 3) - 1)) << 5
    return right | left

def enc(m, key):
    i = 0
    c = []
    Z = "![_°^?'I|o0]$+=-"
    for byte in m:
        temp = r(byte)
        temp =  temp ^ key[i % len(key)]
        i = i + 1
        h = (temp >> 4) & 0xF
        c.append(Z[h])
        l = temp & 0xF
        c.append(Z[l])
    return "".join(c)

if len(sys.argv) != 3:
    sys.exit(1)

m = sys.argv[1].encode("utf-8")
key = sys.argv[2].encode("utf-8")
c = enc(m, key)
print(c)
