#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include "string.h"

#define LIKOVI_MAX 10

typedef struct {
	char * ime;
	char * opis;
} Lik;


Lik *likovi[LIKOVI_MAX];
int brojac_likova = 0;

void ocistiUlazniBuffer() {
    while (getchar() != '\n'){};
}

void prikaziUpute(){
	printf("Ovaj program predstavlja enciklopediju likova.\nMogu se pregledati postojeci likovi i dodati novi.\nProgram treba temeljito testirati jer se jos razvija.\n");
}


void dodajLika(){
	
	if(brojac_likova >= LIKOVI_MAX){
		printf("Dosegnut maksimalan broj likova!\n");
		return;
	}
	
    likovi[brojac_likova] = malloc(sizeof(Lik));
	likovi[brojac_likova]->ime = (char*)malloc(50);
	likovi[brojac_likova]->opis = (char*)malloc(500);
    
    printf("Ime:\n");
	fgets(likovi[brojac_likova]->ime, 50, stdin);
	likovi[brojac_likova]->ime[strcspn(likovi[brojac_likova]->ime, "\n")] = '\0';
	
	printf("Opis:\n");
	fgets(likovi[brojac_likova]->opis, 500, stdin);
	likovi[brojac_likova]->opis[strcspn(likovi[brojac_likova]->opis, "\n")] = '\0';

	brojac_likova++;

	printf("Lik dodan!\n\n");
    
    
    
}

void ispisiTajnuPoruku(){
    FILE *file = fopen("flag.txt", "r");
    if (file == NULL) {
        printf("Greska: Ne moze se otvoriti flag.txt\n");
        return;
    }
    
    char poruka[300];
    if (fgets(poruka, sizeof(poruka), file) != NULL) {
        printf("%s\n", poruka);
    } else {
        printf("Greska pri citanju flag.txt.\n");
    }
    
    fclose(file);
}

void urediLika(){
	
	printf("LIKOVI:\n");
	int i;
	for(i = 0; i<brojac_likova; i++){
		printf(" [%d] %s\n", i+1, likovi[i]->ime);
	}
	
	
	int index;
	printf("Koji lik zelite urediti?:\n");
	int uspjesno = scanf("%d",&index);
	
	
	printf("\n");
	
	if(uspjesno != 1){
		printf("Neispravan unos! Pokusajte ponovo.\n");
        ocistiUlazniBuffer();
        return;
	}
	
	if(index < 1 || index > brojac_likova){
		printf("Neispravan unos! Pokusajte ponovo.\n");
        ocistiUlazniBuffer();
        return;
	}
	
	ocistiUlazniBuffer();
	index = index-1;
	
	
	printf("\nNovo ime (ostavi prazno za ostavljanje starog):\n");
	char privIme[50];
	strcpy(privIme, likovi[index]->ime);
	fgets(likovi[index]->ime, 50, stdin);
	likovi[index]->ime[strcspn(likovi[index]->ime, "\n")] = '\0';
	if(strlen(likovi[index]->ime) == 0){
		strcpy(likovi[index]->ime, privIme);	
	}
	
	printf("Novi opis (ostavi prazno za ostavljanje starog):\n");
	char privOpis[500];
	strcpy(privOpis, likovi[index]->opis);
	fgets(likovi[index]->opis, 600, stdin);
	likovi[index]->opis[strcspn(likovi[index]->opis, "\n")] = '\0';
	if(strlen(likovi[index]->opis) == 0){
		strcpy(likovi[index]->opis, privOpis);	
	}
}

void dodajPocetneLikove(){
	
	likovi[brojac_likova] = malloc(sizeof(Lik));
    likovi[brojac_likova]->ime = (char*)malloc(50);
    likovi[brojac_likova]->opis = (char*)malloc(500);
    
    strcpy(likovi[brojac_likova]->ime, "Heroj");
    strcpy(likovi[brojac_likova]->opis, "Snazan i hrabar ratnik.");
    
    brojac_likova++;
    
    
    likovi[brojac_likova] = malloc(sizeof(Lik));
    likovi[brojac_likova]->ime = (char*)malloc(50);
    likovi[brojac_likova]->opis = (char*)malloc(500);
    
    strcpy(likovi[brojac_likova]->ime, "Zlikovac");
    strcpy(likovi[brojac_likova]->opis, "Podmukli i lukavi carobnjak.");
    
    brojac_likova++;
    
}

void ispisiSveLikove(){
	
	printf("POPIS LIKOVA:\n\n");
	int i;
	for(i = 0; i<brojac_likova; i++){
		printf("Ime: %s\nOpis: %s\n\n", likovi[i]->ime, likovi[i]->opis);
	}
}

int main(){
	
	srand(time(NULL));
	
	dodajPocetneLikove();
	
	int opcija;
	printf("==== Enciklopedija likova ====\n");
	do{
		printf("------------------------------\n");
		printf("1 - Upute\n");
		printf("2 - Pregledaj likove\n");
		printf("3 - Dodaj lika\n");
		printf("4 - Uredi lika\n");
		printf("0 - Izlaz\n");
		printf("\n");
		
		printf("Odabir:\n");
		int uspjesno = scanf("%d",&opcija);
		
		printf("\n");
		
		
		if(uspjesno != 1){
			printf("Neispravan unos! Pokusajte ponovo.\n");
            ocistiUlazniBuffer();
            continue;
		}
		ocistiUlazniBuffer();
		
		switch(opcija){
			case 1:
				prikaziUpute();
				break;
				
			case 2:
				ispisiSveLikove();
				break;
				
			case 3:
				dodajLika();
				break;
				
			case 4:
				urediLika();
				break;
			
			case 0:
				break;
				
			default:
				printf("Neispravan unos! Pokusajte ponovo.\n");
				break;
		}
		
	}while(opcija != 0);
}
