#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include "string.h"

typedef struct {
    int dan;
    int mjesec;
    int godina;
} Datum;

typedef struct{
	char naslov[50];
	char datoteka[50];
	int tajna;
	Datum datum;
} Poruka;


Poruka * poruke;
int ukupnoPoruka = 4;

char trenutnaZona[4];

void prikaziUpute(){
	printf("Marko izraduje program koji ispisuje tajne poruke koje su otkljucane samo na odredeni datum.\nOvaj program ce kasnije sluziti za razvijanje nove mobilne aplikacije.\nProgram treba temeljito testirati jer se jos razvija.");
}

void promijeniZonu(){
	char priv[4];
	printf("Unesi novu zonu (3 znaka):\n");
	fgets(priv,44,stdin);
	strcpy(trenutnaZona,priv);
	printf("Zona promijenjena!\n");
}

void ispisiSadrzajDatoteke(char datoteka[50]){
    FILE *file = fopen(datoteka, "r");
    if (file == NULL) {
        printf("Greska: Ne moze se otvoriti %s\n", datoteka);
        return;
    }
    
    char poruka[300];
    if (fgets(poruka, sizeof(poruka), file) != NULL) {
        printf("%s\n", poruka);
    } else {
        printf("Greska pri citanju %s\n", datoteka);
    }
    
    fclose(file);
}

void ispisiTajnuPoruku(){
    FILE *file = fopen("flag.txt", "r");
    if (file == NULL) {
        printf("Greska: Ne moze se otvoriti flag.txt\n");
        return;
    }
    
    char poruka[300];
    if (fgets(poruka, sizeof(poruka), file) != NULL) {
        printf("%s\n", poruka);
    } else {
        printf("Greska pri citanju flag.txt.\n");
    }
    
    fclose(file);
}

void * ispisiNemaPoruke(){
	printf("Nema dostupne poruke...\n");
}

void ispisiPoruku(int index){
	printf("Naslov: %s\n", poruke[index].naslov);
	ispisiSadrzajDatoteke(poruke[index].datoteka);
}

void provjeriDanasnjuPoruku(){
	
    time_t t;
    struct tm *danas;
    t = time(NULL);
    danas = localtime(&t);
    
    //TODO - vrijeme ovisno o zoni
    printf("Danasnji datum: %02d.%02d.%04d\n", danas->tm_mday, danas->tm_mon + 1,  danas->tm_year + 1900);
    
    int i;
    for(i = 0; i < ukupnoPoruka; i++){
    	if(poruke[i].datum.godina == danas->tm_year + 1900 && poruke[i].datum.mjesec == danas->tm_mon + 1 && poruke[i].datum.dan == danas->tm_mday ){	
    		printf("=Danasnja poruka:\n");
    	
    		ispisiPoruku(i);
    		
    		if(poruke[i].tajna == 1){
		    	ispisiTajnuPoruku();
			}
			return;
		}
	}
    
    printf("Danas nema poruke...\n");
    
}

void ocistiUlazniBuffer() {
    while (getchar() != '\n'){};
}

void pripremiPoruke(){
    poruke = malloc(ukupnoPoruka * sizeof(Poruka));
    if (poruke == NULL) {
        printf("Greska pri alokaciji memorije! Prekidanje programa...\n");
        exit(1);
    }
    
    poruke[0] = (Poruka) {
        "Naslov poruke1",
        "poruke/poruka1.txt",
        0,
        {15, 4, 2021}
    };
    
    poruke[1] = (Poruka) {
        "Naslov poruke2",
        "poruke/poruka2.txt",
        0,
        {13, 3, 2025}
    };
    
    poruke[2] = (Poruka) {
        "Naslov poruke3",
        "poruke/poruka3.txt",
        0,
        {18, 6, 2029}
    };
    
    poruke[3] = (Poruka) {
        "Naslov poruke",
        "poruke/poruka4.txt",
        1,
        {21, 8, 1999}
    };
}

int main(){
	
	srand(time(NULL));
	
	strcpy(trenutnaZona, "CRO");
	
	pripremiPoruke();
	
	
	int opcija;
	printf("==== Vremenske poruke ====\n");
	do{
		printf("------------------------------\n");
		printf("1 - Upute\n");
		printf("2 - Provjeri postoji li danasnja poruka\n");
		printf("3 - Promijeni vremensku zonu\n");
		printf("0 - Izlaz\n");
		printf("\n");
		
		printf("Odabir:\n");
		int uspjesno = scanf("%d",&opcija);
		
		printf("\n");
		
		
		if(uspjesno != 1){
			printf("Neispravan unos! Pokusajte ponovo.\n");
            ocistiUlazniBuffer();
            continue;
		}
		ocistiUlazniBuffer();
		
		switch(opcija){
			case 1:
				prikaziUpute();
				break;
				
			case 2:
				provjeriDanasnjuPoruku();
				break;
				
			case 3:
				promijeniZonu();
				break;
				
				
			default:
				printf("Neispravan unos! Pokusajte ponovo.\n");
				break;
		}
		
	}while(opcija != 0);
}
