gcc -o poruka -no-pie --no-stack-protector -z execstack --static poruka.c
