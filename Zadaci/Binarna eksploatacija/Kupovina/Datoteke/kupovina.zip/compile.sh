gcc -o kupovina kupovina.c
