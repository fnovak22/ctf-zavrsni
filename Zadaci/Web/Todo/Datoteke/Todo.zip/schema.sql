DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS todos;

CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  pwd_hash TEXT NOT NULL,
  admin INT NOT NULL
);

CREATE TABLE todos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  text TEXT NOT NULL,
  due TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

INSERT INTO users(username, pwd_hash, admin) VALUES
  ('admin','747650b44cb4884775ba226ee155361c7eb398bbd456875d371a2b8f74341d43', 0),
  ('testuser','a665a45920422f9d417e4867efdc4fb8a04a1f3ebb67b2d20198bf4a3b5f7e24', 1);
  
INSERT INTO todos(user_id, text) VALUES
  (1, 'A Primjer zadatka 1'),
  (1, 'A Primjer zadatka 2'),
  (2, 'Primjer zadatka 1');
 
