import os
import sqlite3
import re
import hashlib
from datetime import datetime
from flask import Flask, request, jsonify, render_template, redirect, url_for, flash, abort, make_response, session, g

app = Flask(__name__)
app.secret_key = os.urandom(16)
db_path = os.getenv('DATABASE', './data/users.db')

def init_db():
    try:
        os.remove(db_path)
    except FileNotFoundError:
        pass

    os.makedirs(os.path.dirname(db_path), exist_ok=True)

    with open('schema.sql', 'r') as schema_file:
        schema = schema_file.read()

    with sqlite3.connect(db_path) as conn:
        conn.executescript(schema)

init_db()

def get_db():
    if not hasattr(g, 'db'):
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        g.db = conn
    return g.db

@app.teardown_appcontext
def close_db(exception):
    if hasattr(g, 'db'):
        g.db.close()

@app.route('/robots.txt')
def robots_txt():
    return app.send_static_file('robots.txt')

@app.route('/')
def index():
    if 'uid' in session:
        return redirect(url_for('todo'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    
    if session.get('uid'):
        return redirect(url_for('todo'))

    msg = ''
    if request.method == 'POST':
        user_input = request.form.get('username', '').strip()
        pwd = request.form.get('password', '')

        if not user_input or not pwd:
            msg = 'Popunite sva polja!'
            return render_template('login.html', message=msg)

        if re.search(r"(?i)\b(UNION|SELECT|DELETE|INSERT|UPDATE|DROP|OR)\b|--|'|;", user_input):
            msg = 'Neispravan unos korisničkog imena.'
            return render_template('login.html', message=msg)

        pw_hash = hashlib.sha256(pwd.encode()).hexdigest()
        try:
            cur = get_db().cursor()
            cur.execute("SELECT id, username, admin FROM users WHERE username = ? AND pwd_hash = ?;", (user_input, pw_hash))
            row = cur.fetchone()
            if row:
                session['uid'] = row['id']
                resp = make_response(redirect(url_for('todo')))
                resp.set_cookie('admin', str(row['admin']))
                return resp
            else:
                msg = 'Neispravno korisničko ime ili lozinka.'
                
        except Exception as e:
            msg = 'Došlo je do greške. Molimo pokušajte ponovno.'

    return render_template('login.html', message=msg)

@app.route('/register', methods=['GET', 'POST'])
def register():

    if session.get('uid'):
        return redirect(url_for('todo'))

    msg = ''
    if request.method == 'POST':
        user = request.form.get('username', '').strip()
        pwd = request.form.get('password', '')

        if not user or not pwd:
            msg = 'Popunite sva polja!'
            return render_template('register.html', message=msg)

        if len(user) > 32 or not re.fullmatch(r'[A-Za-z0-9_]+', user):
            msg = 'Korisničko ime može biti max 32 znaka (slova, brojke i _).'
            return render_template('register.html', message=msg)

        try:
            pw_hash = hashlib.sha256(pwd.encode()).hexdigest()
            db = get_db()
            db.execute("INSERT INTO users(username, pwd_hash, admin) VALUES (?, ?, ?);", (user, pw_hash, 0) )
            db.commit()
            flash('Registracija uspješna! Možete se prijaviti.')
            return redirect(url_for('login'))
        
        except sqlite3.IntegrityError:
            msg = 'Korisničko ime možda već postoji.'

        except Exception as e:
            msg = 'Neuspješna registracija. Molimo pokušajte ponovo.'

    return render_template('register.html', message=msg)

@app.route('/logout')
def logout():
    session.clear()
    resp = make_response(redirect(url_for('login')))
    resp.delete_cookie('admin')
    return resp

@app.route('/todo', methods=['GET', 'POST'])
def todo():
    uid = session.get('uid')
    if not uid:
        return redirect(url_for('login'))
    db = get_db()
    if request.method == 'POST':
        text = request.form.get('text','').strip()

        due_date = request.form.get('due_date', '').strip()
        due_time = request.form.get('due_time', '').strip()
        
        due = due_date
        if due_date and due_time:
            due += f" {due_time}"
        elif due_date:
            due += " 23:59"

        try:
            due_dt = datetime.strptime(due, "%Y-%m-%d %H:%M")
            due = due_dt.strftime("%Y-%m-%d %H:%M")
        except ValueError:
            due  = None

        if text:
            db.execute("INSERT INTO todos(user_id, text, due) VALUES (?,?,?)", (uid, text, due))
            db.commit()

        return redirect(url_for('todo'))
    
    rows  = db.execute("SELECT id, text, due FROM todos WHERE user_id=?", (uid,))

    items = []
    time_now = datetime.now()
    for r in rows:
        due_str = r['due']
        due_dt = None
        expired = False
        if due_str:
            try:
                due_dt = datetime.strptime(due_str, "%Y-%m-%d %H:%M")
                expired = due_dt < time_now
            except ValueError:
                due_dt = None

        items.append({
            'id': r['id'],
            'text': r['text'],
            'due': due_str,
            'due_dt': due_dt,
            'expired': expired
        })

    items.sort(key=lambda x: (x['due_dt'] is None, x['due_dt'] or datetime.max))
    return render_template('todo.html', todos=items)

@app.route('/todo/delete/<int:todo_id>', methods=['POST'])
def delete_todo(todo_id):
    uid = session.get('uid')
    if not uid:
        return redirect(url_for('login'))
    db = get_db()
    cur = db.execute("SELECT user_id FROM todos WHERE id=?", (todo_id,))
    row = cur.fetchone()
    if not row or row['user_id'] != uid:
        abort(403)
    db.execute("DELETE FROM todos WHERE id=?", (todo_id,))
    db.commit()
    return redirect(url_for('todo'))

@app.route('/admin/flag', methods=['GET'])
def admin_flag():
    is_admin = request.cookies.get('admin')
    if is_admin != '1':
        abort(403)
    return jsonify(flag="CTFFOI[CcoOk1e_TamP_P3r1ng]")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
