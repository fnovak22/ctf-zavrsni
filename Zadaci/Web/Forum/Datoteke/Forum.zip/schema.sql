CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  about_me TEXT DEFAULT '',
  flag TEXT NOT NULL
);

CREATE TABLE posts (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL,
  content TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

INSERT INTO users (username, password_hash, about_me, flag) VALUES
  ('backup', '9a235a6fdd7fa06c7278f9087bf96ae51d72f3974bfe4b96c970b4f053320685', 'Backup account - trenutno nije u upotrebi', ''),
  ('test_korisnik', '7578a0c68e6e4934ee7e929ef138c936c14905920d208a00c45275ee11683624', 'Test account - trenutno nije u upotrebi', ''),
  ('luka654', '9885d1cb5e0df3d9fde7ffd1076688346ce49160ada14a63bc81c9d29ba8f985', 'Administrator Foruma', 'CTFFOI[SQ7_Inj3ct1NG__F0rUUm]');

INSERT INTO users (username, password_hash, about_me, flag) VALUES
  ('filip_f', '3ac73bdf78813e3bd2b871f906638abd64553ce301bd0d3b80ed2fee37b284f1', 'Volim raspravljati o gaming temama i PC buildingu', ''),
  ('2_pero_2', 'f14deb70af534ee1305dfc5fbbe80899b4928f0b6ae48c89101bf9756837ad76', 'Volim IT novosti i mačke :)', '');

INSERT INTO posts (user_id, content, created_at) VALUES
  (3, 'Dobrodošli na Forum! Ako imate pitanja ili želite prijaviti neki problem, slobodno se obratite meni. :)', '2025-07-01 10:13:02'),
  (4, 'Pozdrav svima! Ovo je moja prva poruka na forumu. Veselim se novim diskusijama i novim prijateljstvima.', '2025-07-02 14:31:55'),
  (4, 'Nedavno sam počeo učiti programiranje i želio bih podijeliti svoje iskustvo. Ako netko ima savjete, slobodno pišite!', '2025-07-03 09:42:04'),
  (5, 'Bokić, Jako mi je drago što sam se pridružio ovom novom forumu. Volim rasprave o novostima u tehnologiji.', '2025-07-03 16:20:32'),
  (5, 'Nego... Zanima me kako vi ostali pristupate učenju novih alata i tehnologija u IT-u? Koje su vam najdraže metode?', '2025-07-04 11:06:03');

