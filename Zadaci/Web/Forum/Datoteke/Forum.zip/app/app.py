import logging
from flask import Flask, request, render_template, g, redirect, session, url_for, flash
import sqlite3
import os
import hashlib
import re

app = Flask(__name__)
app.secret_key = os.urandom(16)
db_path = os.getenv('DATABASE', '/data/users.db')

def init_db():
    try:
        os.remove(db_path)
    except FileNotFoundError:
        pass

    os.makedirs(os.path.dirname(db_path), exist_ok=True)

    with open('schema.sql', 'r') as schema_file:
        schema = schema_file.read()

    with sqlite3.connect(db_path) as conn:
        conn.executescript(schema)

init_db()

def get_db():
    if not hasattr(g, 'db'):
        g.db = sqlite3.connect(db_path)
    return g.db

@app.teardown_appcontext
def close_db(exception):
    if hasattr(g, 'db'):
        g.db.close()

@app.route('/')
def index():
    if 'user' in session:
        return redirect(url_for('forum'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():

    if session.get('user'):
        return redirect(url_for('forum'))

    msg = ''
    
    if request.method == 'POST':
        user_input = request.form.get('username', '')
        pwd  = request.form.get('password', '')

        if(user_input == '' or pwd == ''):
            msg = 'Popunite sva polja!'
            return render_template('login.html', message=msg)

        if re.search(r"(?i)\b(UNION|SELECT|DELETE|INSERT|UPDATE|DROP)\b|;", user_input):
            msg = 'Neispravan unos korisničkog imena.'
            return render_template('login.html', message=msg)

        pw_hash = hashlib.sha256(pwd.encode()).hexdigest()

        query = f"SELECT username FROM users WHERE username = '{user_input}' AND password_hash = '{pw_hash}';"

        try:
            cursor = get_db().cursor()
            cursor.execute(query)
            row = cursor.fetchone()
            if row:
                session['user'] = row[0] #row[0] = username from DB
                return redirect(url_for('forum'))
            else:
                msg = 'Pogrešno korisničko ime ili lozinka.'

        except Exception as e:
            msg = 'Došlo je do greške. Molimo pokušajte ponovno.'

    return render_template('login.html', message=msg)

@app.route('/register', methods=['GET', 'POST'])
def register():

    if request.method == 'POST':
        user = request.form.get('username', '')
        pwd  = request.form.get('password', '')
        about = request.form.get('about', '')

        if(user == '' or pwd == '' or about == ''):
            msg = 'Popunite sva polja!'
            return render_template('register.html', message=msg)

        if len(user) > 32:
            msg = 'Maksimalna duljina korisničkog imena je 32 znaka!'
            return render_template('register.html', message=msg)

        if not re.fullmatch(r'[A-Za-z0-9_]+', user):
            msg = 'Korisničko ime može sadržavati samo velika i mala slova, brojke i donju crtu (_)!'
            return render_template('register.html', message=msg)

        try:
            hash_pwd = hashlib.sha256(pwd.encode()).hexdigest()
            cursor = get_db().cursor()

            cursor.execute("INSERT INTO users(username, password_hash, about_me, flag) VALUES (?, ?, ?, '');", (user, hash_pwd, about))
            get_db().commit()

            flash('Registracija je uspješna! Možete se prijaviti!')      
            return redirect(url_for('login'))                          

        except Exception as e:
            msg = 'Neuspješna registracija. Korisničko ime možda već postoji.'
            return render_template('register.html', message=msg)

    return render_template('register.html')

@app.route('/forum', methods=['GET', 'POST'])
def forum():

    if 'user' not in session:
        return redirect(url_for('login'))
    
    user = session['user']
    msg = ''
    cursor = get_db().cursor()

    if request.method == 'POST':
        content = request.form.get('content', '')
        try:
            cursor.execute("SELECT id FROM users WHERE username = ?", (user,))
            row = cursor.fetchone()
            if not row:
                msg = 'Korisnik nije pronađen.'
            else:
                user_id = row[0]
                cursor.execute("INSERT INTO posts(user_id, content) VALUES (?, ?);", (user_id, content))
                get_db().commit()

        except Exception as e:
            msg = 'Dogodila se greška. Molimo pokušajte ponovo.'

    cursor.execute("SELECT users.username, posts.content, posts.created_at FROM posts JOIN users ON posts.user_id = users.id ORDER BY posts.id ASC;")
    posts = cursor.fetchall()
    return render_template('forum.html', user=user, posts=posts, message=msg)

@app.route('/profile')
def profile():

    if 'user' not in session:
        return redirect(url_for('login'))
    
    user = session['user']
    cursor = get_db().cursor()
    cursor.execute( "SELECT about_me, flag FROM users WHERE username = ?;", (user,))
    row = cursor.fetchone()
    about = row[0] if row else ''
    flag = row[1] if row and user == 'luka654' else None
    return render_template('profile.html', user=user, about=about, flag=flag)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
