
def provjeriImeVarijable(ime):
    zabranjeni_znakovi = {"(",")","+","-","=","/","*","_",",",".","'",'"',"$",":"," ","\\","a"}
    if(len(ime) > 2):
        print("ERROR - Dozvoljen je samo 1 znak za ime varijable!")
        return False
        
    if (set(ime) & zabranjeni_znakovi):
        print("ERROR - Detektirani zabranjeni znakovi")
        return False
    
    return True

def provjeriVrijednostVarijable(vrijednost):
    zabranjeni_znakovi = {"(",")","+","-","/","*","_",",",".","'",'"',"$",":"," ","\\"}
    if(len(vrijednost) > 5):
        print("ERROR - Dozvoljen je samo 5 znakova za vrijednost varijable!")
        return False
    if (set(vrijednost) & zabranjeni_znakovi):
        print("ERROR - Detektirani zabranjeni znakovi")
        return False
    
    if (any(ord(x) > 128 for x in vrijednost)):
        print("ERROR - Morate unijeti validan ASCII znak")
        return False

    return True
    

def provjeriIspravnost(ime):
    if(eval(f"(({ime} / 37) > a )")):
        print("ERROR - Krivo 1")
        return False

    if(eval(f"({ime}+a<1337)")):
        print("ERROR - Krivo 2")
        return False
    
    if(eval(f"(({ime}*20) != (a * (-2 + (4 * 3) + 10 )))")):
        print("ERROR - Krivo 3")
        return False
    
    if(eval(f"({ime}+a>7331)")):
        print("ERROR - Krivo 4")
        return False

    if(eval(f"({ime}%(int(a/8) + 1) != 102)")):
        print("ERROR - Krivo 5")
        return False
    
    return True

a=2
ime_varijable = input("Ime varijable (1 znak): ")

if(not provjeriImeVarijable(ime_varijable)):
	exit(0)

vrijednost_varijable = input("Vrijednost varijable (do 5 znaka): ")

if(not provjeriVrijednostVarijable(vrijednost_varijable)):
	exit(0)

exec(f"{ime_varijable}={vrijednost_varijable}")

if(provjeriIspravnost(ime_varijable)):
    with open("flag.txt", "r") as f:
        print(f.read())
